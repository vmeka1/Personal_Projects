function sendData() {
    var form = document.getElementById("authForm");
    function handleForm(event) { event.preventDefault(); } //prevent refresh
    form.addEventListener('submit', handleForm);

    //Function sends credentails to server
    async function postData(){

      let userField = document.getElementById("username").value;
      let passField = document.getElementById("password").value;

      let json = {username: userField, password: passField};
      //sets up to make a post request
      var options = {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(json)
      };
      //sends POST object to server
      const response = await fetch('/auth', options);
      const responseJson = await response.json();

      //Show on the webpage
      console.log(responseJson);
      showData(responseJson.message);

    }//end postData()

    postData();

    //Display database info to webpage
    async function showData(message){
      let responseDiv = document.createElement('div');
      responseDiv.textContent = message;
      document.body.append(responseDiv);
    }//end showData
}//end sendData()
