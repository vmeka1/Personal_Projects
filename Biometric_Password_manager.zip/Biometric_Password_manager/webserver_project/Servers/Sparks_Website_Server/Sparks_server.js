//uses express for server functionality and nedb for database functionality
const express = require('express');
const Datastore = require('nedb');

//creates the port and sets certain configurations
const app = express();
app.listen(3001, () => console.log('Listening on port 3001'));
const defaults = {index: "Sparks.html"}; //Changes the default page
app.use(express.static('public', defaults));//Sets up directory for reading
app.use(express.json({limit: '1mb'}) ); //limits connections to 1mb size

// Loads Database
const database = new Datastore('Sparks_database.db');
database.loadDatabase();

/////////////api that the client can either send GET or POST requests to
//Default get request returns entire database (for testing purposes)
app.get('/api', (request,response) => {
  database.find({}, //What to find in the database
     (err, data) =>
     {//Callback
       if (err){response.end();}

       response.json(data);
     }//end Callback
   );//end database.find
});//end get

//Authenticate
app.post('/auth', (request,response) => {
  console.log('Attempting to authenticate...');
  console.log(request.body);//Show received data
  const data = request.body;
 database.find(
   {"username": data.username,
    "password": data.password},
    (err,found) =>
    {//For the entries that were returned
      if (found.length == 0  || found.length > 1)
      {//Got extra or no records
        let message = "login Failed";
        json = {message: message};//Sends message back
        console.log(message);
        if(err){console.log(err);}
        response.json(json);
      }// end if
      else {
             let message = "login successful";
             json = {message: message};//Sends mesage back
             console.log(message);
             response.json({message: message});
           }
    }); //finds all elements with matching username
});//end auth post
