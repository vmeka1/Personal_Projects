//uses express for server functionality and nedb for database functionality
const express = require('express');
const Datastore = require('nedb');

//creates the port and sets certain configurations
const app = express();
app.listen(3000, () => console.log('Listening on port 3000'));
const defaults = {index: "Extension_Login.html"}; //Changes the default page
app.use(express.static('public', defaults));//Sets up directory for reading
app.use(express.json({limit: '1mb'}) ); //limits connections to 1mb size

//stores master credentials for extension login user
const masterDB = new Datastore('master_credentials.db');
masterDB.loadDatabase();

//stores website credentials for respective users
const websiteDB = new Datastore('website_credentials.db');
websiteDB.loadDatabase();

//api that the client can either send GET or POST requests to
app.get('/api', (request,response) => {
  masterDB.find({}, //What to find in the database
     (err, data) =>
     {//Callback
       if (err){response.end();}

       response.json(data);
     }//end Callback
   );//end database.find
});//end get

//api that the client can either send GET or POST requests to
//Echoes data and adds to database
app.post('/api', (request,response) => {
  console.log('I got a request');
  const data = request.body;
  masterDB.insert(data);
  response.json(data);
});


//Check all master credentials
app.post('/auth', (request,response) => {
  console.log('Attempting to authenticate...');
  console.log(request.body);//Show received data
  const data = request.body;
 masterDB.find(
   {"username": data.username,
    "password": data.password,
    "visualID": data.visualID},
    (err,found) =>
    {//For the entries that were returned
      console.log(found);
      if (found.length == 0  || found.length > 1)
      {
        let message = "Authentication Failed";
        json = {message: message};//Sends all this back
        console.log(message);
        if(err){console.log(err);}
        response.json(json);
      }// end if
      else {
        let message = "Authentication Successful";
        json = {message: message};//Sends all this back
        console.log(message);
        if(err){console.log(err);}
        response.json(json);
      }//end else
    }); //finds all elements with matching username
});//end auth post

//code that we would like to use, but halts unexpectedly
/*
app.post('/auth', (request,response) => {
  console.log('Attempting to authenticate...');
  console.log(request.body);//Show received data
  const data = request.body;
  let json;
  masterDB.find(
   {"username": data.username,
    "password": data.password,
    "visualID": data.visualID},
    (err,found) =>
    {//For the entries that were returned
      console.log(found);
      if (found.length == 0  || found.length > 1)
      {//No matches in the database, or multiple matches (bad)
        let message = "Authentication Failed";
        console.log(message);
        if(err){console.log(err);}
        //Send failed to client
        json = {message: message};//Sends all this back
        response.json(json);
        return;
      }// end if
      let id  = found[0]._id;//Grabs the foreign key for a database join
      let url = found[0].url;
      console.log("ID to search for: " + id);
      websiteDB.find(
        {"_id": id,
        "url:": url},
        (inner_err, creds) =>
        {//For the cedentials that were returned
          if(inner_err){console.log(err);};
          console.log("Retriving Website Credentials");
          if (creds.length == 0 || creds.length > 1)
          {
            let message = "Unable to get crentials for this site";
            console.log(message + ':\n' + creds);

            json = {message: message};//Sends all this back
            response.json(json);
            return;
          }
          else
          {//We found the creds
            credentials = creds[0];//Pulls the only item oout of the array
            credentials_package = {username: credentials.username, password: credentials.pasword};
            console.log("Auth Successful");

            response.json(credentals_package);//Sends back all to the server
            return;
          }//end if
        }); //end of inner query
    });//End outer query
    console.log("End of func");
});//end auth post
*/
