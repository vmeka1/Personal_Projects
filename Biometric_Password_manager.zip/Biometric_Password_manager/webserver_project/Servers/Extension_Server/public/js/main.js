//global variable used in postData() to send images to server
var video;

function sendData() {

    //model loaded in from the same dir as the html
    classifier = ml5.imageClassifier('model.json');

    //user entered url
    let webURL = document.getElementById('website').value;

    //checks for empty url field
    if (webURL == "") {
      //DO nothing
    }
    else
    {
    let newTab = window.open(webURL, '_blank');
    }

    //predicts the user and prints name to console if confidence value high enough
    function nameFromResults(results){
      let max = 0;
      let i = 0;
      let maxIndex = -1;
      for (r in results)
      {
        if (results[i].confidence > max)
        {
          max = results[i].confidence;
          maxIndex = i;
        }
        i++;
      }
      if (results[maxIndex].confidence >= 0.70)
      {
        console.log(results);
        return results[maxIndex].label;
      }
      else
      {
        console.log(results);
        return 'Noone';
      }
    }//end model results

    //Function sends credentails and image to server
    function postData(){
      //takes screenshot of video field and moves it to a canvas as an image
      video.loadPixels();
      //turns image into base64
      const images = video.canvas.toDataURL();
      //function pointer to callback where second argument is the array of 3 classes
      console.log(classifier.classify(video, modelResults));
      //packs image and credentials into an object
      const data = {username, password, images};
      //sets up to make a post request
      var options = {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(data)
      };
      //sends POST object to server
      //fetch('/api', options).then(response => {console.log(response);} );
    }//end postData()
    //postData();

    async function sendCredentials()
      {//Master Credentials
      let userField = document.getElementById("username").value;
      let passField = document.getElementById("password").value;
      //Returns
      let results =  await classifier.classify(video, (err,_) => {});
      let visualID = nameFromResults(results);

      let json = {username: userField, password: passField, visualID: visualID };

      var options = {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(json)
      };

      //Send credentials
      const response = await fetch('/auth', options);
      const responseJson = await response.json();

      //Show on the webpage
      console.log(responseJson);
      showData(responseJson.message);

    }//end sendCredentials()
    sendCredentials();
}//end sendData()

//Makes a canvas upon execution/creation of p5 instance
function setup(){
noCanvas();
video = createCapture(VIDEO);
video.parent('video_player');
video.size(320,240);
}

//Display database info to webpage
async function showData(message){
  let responseDiv = document.createElement('div');
  responseDiv.textContent = message;
  document.body.append(responseDiv);
}//end showData
