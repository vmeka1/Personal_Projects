//uses express for server functionality and nedb for database functionality
const express = require('express');
const Datastore = require('nedb');

//creates the port and sets certain configurations
const app = express();
app.listen(3000, () => console.log('Listening on port 3000'));
const defaults = {index: "public/Extension_Login.html"}; //Changes the default page
app.use(express.static('public', defaults));//Sets up directory for reading
app.use(express.json({limit: '1mb'}) ); //limits connections to 1mb size

// Simple Authentication Password Database
//No Security
const database = new Datastore('database.db');
database.loadDatabase();

//api that the client can either send GET or POST requests to
app.get('/api', (request,response) => {
  database.find({}, //What to find in the database
     (err, data) =>
     {//Callback
       if (err){response.end();}

       response.json(data);
     }//end Callback
   );//end database.find
});//end get

//api that the client can either send GET or POST requests to
//Echoes data and adds to database
app.post('/api', (request,response) => {
  console.log('I got a request');
  const data = request.body;
  database.insert(data);
  response.json(data);
});

//Check all master credentials
app.post('/auth', (request,response) => {
  console.log('Attempting to authenticate...');
  console.log(request.body);//Show received data
  const data = request.body;
 masterDB.find(
   {"username": data.username,
    "password": data.password,
    "visualID": data.visualID},
    (err,found) =>
    {//For the entries that were returned
      console.log(found);
      if (found.length == 0  || found.length > 1)
      {
        let message = "Authentication Failed";
        json = {message: message};//Sends all this back
        console.log(message);
        if(err){console.log(err);}
        response.json(json);
      }// end if
      else {
        let message = "Authentication Successful";
        json = {message: message};//Sends all this back
        console.log(message);
        if(err){console.log(err);}
        response.json(json);
      }//end else
    }); //finds all elements with matching username
});//end auth post
