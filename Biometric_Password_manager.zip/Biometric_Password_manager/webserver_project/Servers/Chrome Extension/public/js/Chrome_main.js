//Cleaner version of the main.js that flows better and uses callbacks
document.addEventListener('DOMContentLoaded', Everything, false);

function Everything()
{//Runs when DOM is loaded

  //Initialize p5
  let myp5 = ReadyP5();//Ensures p5 is done loading
  console.log("P5 is done loading");

  //loadModel
    let model = loadModel().then( () => {
    console.log("Model is loaded");

  //The rest only executes after button press
  document.getElementById('submit_btn').addEventListener('click', () =>
  {
    //Run model
      //let results = RunModel(model, myp5);
      console.log('model ran');

    //extract name from results
      //let name = ExtractNameFromResults(results);
      let name = "Vince";
      console.log('Extract ran');
     console.log('person identified' + name);

    //Send Credentials
      let response = sendCredentials(name);
      console.log('send credentials ran');
      console.log(response);

    //displays auth success/fail
      showData(response.message);

  });//end button click
});
}// end everything


function ReadyP5()
{
  //Initializer to help create a p5 instance later. Passed a "future p5"
    let p5InitFunc = function(fp5)
  {
    //Sets the setup function to point to this when this initializer is used
    fp5.setup = function(){
      console.log("p5 is being initialized");
      fp5.noCanvas();
      //fp5.createCanvas(200,200);
      fp5.video = fp5.createCapture(fp5.VIDEO);
      fp5.video.size(500,500);
    };//end setup
    //Sets the draw function to whaterver we want when this initializer is used
    fp5.draw = function(){console.log("DRAW");};


    fp5.makeDiv = function(body){body.append(document.createElement('div'));};//only runs when actual constructor is called
    //fp5.createVideo(div){div.appendElement()}
  }//end future init

  //Creates a new instancee of p5 using a p5Init object tjat is a dummy instance of p5 whose propertie are copied over when this acual constructor runs.
  return myp5 = new p5(p5InitFunc);//myp5 becomes what fp5 always dreamed of being
}//end ReadyP5


async function loadModel()
{
  //loads the model from the file
    let classifier = await ml5.imageClassifier('model.json', ()=> {console.log("model officially loaded"); return classifier;});
}//end LoadModel


function RunModel(classifier, myp5)
{
  //Video pased from p5, model runs on the video
  console.log(classifier);
  console.log(classifier.classify(myp5.VIDEO, (e,r)=>{}));
  var results;
  classifier.classify(myp5.VIDEO, (err,results) => {/* check for errors*/ console.log("Results are officially done");}); //passes an anonymous result variable by reference.. Prefer to use final return value for more flexibility
  return results;
}//end Run Model


function ExtractNameFromResults(results){
  let max = 0;
  let i = 0;
  let maxIndex = -1;
  for (r in results)
  {
    if (results[i].confidence > max)
    {
      max = results[i].confidence;
      maxIndex = i;
    }
    i++;
  }
  ///console.log(maxIndex);
  if (results[maxIndex].confidence >= 0.70)
  {
    console.log(results);
    return results[maxIndex].label;
  }
  else
  {
    console.log(results);
    return 'Noone';
  }
}//end model results


async function sendCredentials(name)
  {//Master Credentials
      console.log('sendCredentials ran');
  let userField = document.getElementById("username").value;
  let passField = document.getElementById("password").value;
  let visualID = name;

  let json = {username: userField, password: passField, visualID: visualID };
  //console.log(json);

  var options = {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(json)
  };

  //Send credentials
  const response = fetch('/auth', options);
  const responseJson = await response.json();

  return responseJson;

}//end sendCredentials()


//Display database info to webpage
async function showData(message){
  let genericDiv = document.createElement('div');
  genericDiv.textContent = message;
  document.body.append(genericDiv);
}//end showData
